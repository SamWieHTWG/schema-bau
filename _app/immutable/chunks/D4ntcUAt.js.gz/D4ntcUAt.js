const s="https://samwieHTWG.github.io/schema-bau";export{s as B};
