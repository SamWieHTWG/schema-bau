const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./DjOT-GKG.js","./xhVCQ2rC.js","./DDx_huEc.js"])))=>i.map(i=>d[i]);
import{c as mt,_ as xt}from"./BA9oQBVg.js";import"./CWj6FrbW.js";import{a as X,C as Z,b as j,s as gt}from"./BnBsQ0Ec.js";import{f as C,e as E,o as bt,J as st,g as J,v as vt,D as k,F as L,t as V,s as A,C as N,w as T,z as O,A as yt,G as ft,B as M,K as F,x as _t,L as Tt}from"./xhVCQ2rC.js";import{c as wt,s as ut}from"./DjOT-GKG.js";import{l as $,p as w,i as U,c as Et}from"./CgmtfOra.js";import{c as Pt,a as ht,s as q,G as kt,R as Lt,C as W}from"./wTaNA5UC.js";import{F as ct}from"./DP0sIMzG.js";import{e as h}from"./DDx_huEc.js";import{b,C as Ct,s as St}from"./CwppPwzA.js";var Rt=C("<span></span>");function Ht(r,t){const a=$(t,["children","$$slots","$$events","$$legacy"]),n=$(a,["size"]);let l=w(t,"size",8,"default");var e=Rt();X(e,o=>({...n,[Z]:o}),[()=>({"bx--tag":!0,"bx--tag--sm":l()==="sm","bx--skeleton":!0})]),h("click",e,function(o){b.call(this,t,o)}),h("mouseover",e,function(o){b.call(this,t,o)}),h("mouseenter",e,function(o){b.call(this,t,o)}),h("mouseleave",e,function(o){b.call(this,t,o)}),E(r,e)}var zt=C("<span> </span>"),Mt=C('<div><!> <button type="button"><!></button></div>'),Ft=C("<div><!></div>"),At=C("<button><!> <span><!></span></button>"),Dt=C("<div><!></div>"),Nt=C("<div><!> <span><!></span></div>");function Ut(r,t){const a=Pt(t),n=$(t,["children","$$slots","$$events","$$legacy"]),l=$(n,["type","size","filter","disabled","interactive","skeleton","title","icon","id"]);bt(t,!1);let e=w(t,"type",8,void 0),o=w(t,"size",8,"default"),c=w(t,"filter",8,!1),i=w(t,"disabled",8,!1),f=w(t,"interactive",8,!1),v=w(t,"skeleton",8,!1),m=w(t,"title",8,"Clear filter"),u=w(t,"icon",8,void 0),y=w(t,"id",24,()=>"ccs-"+Math.random().toString(36));const D=wt();ht();var Y=st(),dt=J(Y);{var K=S=>{Ht(S,Et({get size(){return o()}},()=>l,{$$events:{click(P){b.call(this,t,P)},mouseover(P){b.call(this,t,P)},mouseenter(P){b.call(this,t,P)},mouseleave(P){b.call(this,t,P)}}}))},Q=(S,P)=>{{var tt=z=>{var p=Mt();X(p,s=>({"aria-label":m(),id:y(),...l,[Z]:s}),[()=>({"bx--tag":!0,"bx--tag--disabled":i(),"bx--tag--filter":c(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var R=k(p);q(R,t,"default",{props:{class:"bx--tag__label"}},s=>{var _=zt();j(_,1,"",null,{},{"bx--tag__label":!0});var B=k(_,!0);L(_),V(()=>ut(B,e())),E(s,_)});var g=A(R,2);j(g,1,"",null,{},{"bx--tag__close-icon":!0});var x=k(g);Ct(x,{}),L(g),L(p),V(()=>{gt(g,"aria-labelledby",y()),g.disabled=i(),gt(g,"title",m())}),h("click",g,function(s){b.call(this,t,s)}),h("click",g,St(()=>{D("close")})),h("mouseover",g,function(s){b.call(this,t,s)}),h("mouseenter",g,function(s){b.call(this,t,s)}),h("mouseleave",g,function(s){b.call(this,t,s)}),E(z,p)},et=(z,p)=>{{var R=x=>{var s=At();X(s,d=>({type:"button",id:y(),disabled:i(),"aria-disabled":i(),tabindex:i()?"-1":void 0,...l,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--interactive":!0,"bx--tag--disabled":i(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var _=k(s);{var B=d=>{var H=Ft();j(H,1,"",null,{},{"bx--tag__custom-icon":!0});var lt=k(H);q(lt,t,"icon",{},nt=>{var I=st(),ot=J(I);mt(ot,u,(rt,it)=>{it(rt,{})}),E(nt,I)}),L(H),E(d,H)};U(_,d=>{(a.icon||u())&&d(B)})}var G=A(_,2),at=k(G);q(at,t,"default",{},null),L(G),L(s),h("click",s,function(d){b.call(this,t,d)}),h("mouseover",s,function(d){b.call(this,t,d)}),h("mouseenter",s,function(d){b.call(this,t,d)}),h("mouseleave",s,function(d){b.call(this,t,d)}),E(x,s)},g=x=>{var s=Nt();X(s,d=>({id:y(),...l,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--disabled":i(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var _=k(s);{var B=d=>{var H=Dt();j(H,1,"",null,{},{"bx--tag__custom-icon":!0});var lt=k(H);q(lt,t,"icon",{},nt=>{var I=st(),ot=J(I);mt(ot,u,(rt,it)=>{it(rt,{})}),E(nt,I)}),L(H),E(d,H)};U(_,d=>{(a.icon||u())&&d(B)})}var G=A(_,2),at=k(G);q(at,t,"default",{},null),L(G),L(s),h("click",s,function(d){b.call(this,t,d)}),h("mouseover",s,function(d){b.call(this,t,d)}),h("mouseenter",s,function(d){b.call(this,t,d)}),h("mouseleave",s,function(d){b.call(this,t,d)}),E(x,s)};U(z,x=>{f()?x(R):x(g,!1)},p)}};U(S,z=>{c()?z(tt):z(et,!1)},P)}};U(dt,S=>{v()?S(K):S(Q,!1)})}E(r,Y),vt()}const Bt="http://localhost:8000",Gt={format:"A4",margin:{top:"20mm",bottom:"20mm",left:"15mm",right:"15mm"},printBackground:!0,displayHeaderFooter:!1,landscape:!1,scale:1};function pt(r){const t=document.createElement("div");t.innerHTML=r;const a=[];return t.querySelectorAll("h1, h2, h3, h4, h5, h6").forEach((l,e)=>{var f;const o=parseInt(l.tagName.charAt(1)),c=((f=l.textContent)==null?void 0:f.trim())||"";let i=l.id;i||(i=`heading-${e+1}`,l.id=i),c&&a.push({id:i,text:c,level:o,originalTag:l.tagName.toLowerCase()})}),t.innerHTML="",a}function It(r,t="Inhaltsverzeichnis"){if(r.length===0)return"";let a=`<div class="table-of-contents">
    <h2 class="toc-title">${t}</h2>
    <nav class="toc-nav">`,n=0;r.forEach((l,e)=>{if(l.level>n)for(let c=n;c<l.level;c++)a+='<ul class="toc-list">';else if(l.level<n)for(let c=l.level;c<n;c++)a+="</ul>";const o=l.pageNumber!==void 0?l.pageNumber.toString():"...";a+=`<li class="toc-item toc-level-${l.level}">
      <a href="#${l.id}" class="toc-link">
        <span class="toc-text">${l.text}</span>
        <span class="toc-dots"></span>
        <span class="toc-page-number">${o}</span>
      </a>
    </li>`,n=l.level});for(let l=0;l<n;l++)a+="</ul>";return a+="</nav></div>",a}function Ot(){const r=[];for(const t of Array.from(document.styleSheets))try{const a=t.cssRules||t.rules;a&&Array.from(a).forEach(n=>n.cssText&&r.push(n.cssText))}catch{t.href&&r.push(`@import url("${t.href}");`)}return document.querySelectorAll("style").forEach(t=>t.textContent&&r.push(t.textContent)),r.join(`
`)}async function qt(r,t={}){const a=document.createElement("div");a.style.position="absolute",a.style.left="-9999px",a.style.top="-9999px",a.style.visibility="hidden",document.body.appendChild(a);try{const{mount:n,unmount:l}=await xt(async()=>{const{mount:u,unmount:y}=await import("./DjOT-GKG.js").then(D=>D.f);return{mount:u,unmount:y}},__vite__mapDeps([0,1,2]),import.meta.url);await document.fonts.ready;const e=n(r,{target:a,props:t});await new Promise(u=>setTimeout(u,100));let o="",c=0;const i=20;for(let u=0;u<i;u++){const y=a.innerHTML;if(y===o){if(c++,c>=3)break}else c=0;o=y,await new Promise(D=>setTimeout(D,200))}const f=a.querySelectorAll("img");f.length>0&&await Promise.all(Array.from(f).map(u=>u.complete?Promise.resolve():new Promise(y=>{u.addEventListener("load",y),u.addEventListener("error",y),setTimeout(y,3e3)})));const v=a.innerHTML;if(l(e),!v.trim())throw new Error("Component rendered empty HTML");const m=Ot();return{html:v,styles:m}}finally{a.remove()}}async function jt(r){const t=[];let a="",n="";for(const[l,e]of r.entries()){const{component:o,props:c={},title:i=`Page ${l+1}`}=e,{html:f,styles:v}=await qt(o,c),m=i?`<div class="pdf-page">
           <h1 class="page-title" id="page-${l+1}">${i}</h1>
           ${f}
         </div>`:`<div class="pdf-page" id="page-${l+1}">${f}</div>`;t.push({title:i,html:m}),a+=m,l===0&&(n=v)}return{html:a,styles:n,pageInfo:t}}function Jt(r){const t=window.location.origin;let a=r.replace(/url\(['"]?\/(fonts\/[^'"()]+)['"]?\)/g,`url('${t}/$1')`);return a+=`
    /* Fallback font rules for PDF generation */
    body, html, * {
      font-family: 'Quicksand', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
    }
  `,a}function Vt(r,t,a="Report",n={}){const l=n.calculationReportSubtitle||"Berechnungsbericht",e=Jt(t);let o=r,c="";if(n.includeTableOfContents){const i=n.customTocEntries||pt(r);if(i.length>0&&(c=It(i,n.tocTitle),!n.customTocEntries)){const f=document.createElement("div");f.innerHTML=r,i.forEach(v=>{const m=f.querySelector(`#${v.id}`);m&&!m.id&&(m.id=v.id)}),o=f.innerHTML}}return`<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>${a}</title>
  <style>
    ${e}
    html, body { margin:0; padding:0; width:100%; background:white; }
    .pdf-header { text-align:center; margin-bottom:20px; }
    .pdf-content { width:100%; margin:8px; }
    button { display:none; }

    .table-of-contents {
      margin: 30px 0;
      padding: 20px 0;
      page-break-after: always;
    }

    .toc-title {
      margin: 0 0 20px 0;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      font-size: 1.5em;
      color: #333;
    }

    .toc-nav {
      margin: 0;
    }

    .toc-list {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .toc-item {
      margin: 8px 0;
      line-height: 1.4;
    }

    .toc-link {
      display: flex;
      text-decoration: none;
      color: #333;
      padding: 4px 0;
      align-items: baseline;
    }

    .toc-link:hover {
      color: #0066cc;
    }

    .toc-text {
      flex-shrink: 0;
      margin-right: 8px;
    }

    .toc-dots {
      flex-grow: 1;
      border-bottom: 1px dotted #666;
      margin: 0 8px;
      height: 1px;
      margin-bottom: 4px;
    }

    .toc-page-number {
      flex-shrink: 0;
      font-style: italic;
      color: #666;
      min-width: 30px;
      text-align: right;
      font-weight: 500;
    }

    .toc-level-1 { margin-left: 0; }
    .toc-level-2 { margin-left: 20px; }
    .toc-level-3 { margin-left: 40px; }
    .toc-level-4 { margin-left: 60px; }
    .toc-level-5 { margin-left: 80px; }
    .toc-level-6 { margin-left: 100px; }

    .toc-level-2 .toc-text { font-size: 0.95em; }
    .toc-level-3 .toc-text { font-size: 0.9em; }
    .toc-level-4 .toc-text { font-size: 0.85em; }
    .toc-level-5 .toc-text { font-size: 0.8em; }
    .toc-level-6 .toc-text { font-size: 0.75em; }

    .pdf-page {
      page-break-before: always;
      margin-bottom: 30px;
      width: 100%;
    }

    .pdf-page:first-child {
      page-break-before: auto;
    }

    .page-title {
      margin-top: 0;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      color: #333;
      font-size: 1.8em;
    }
  </style>
</head>
<body>
  <div class="pdf-header">
    ${n.headerHTML||`<h1>${a}</h1>
    <p>${l}</p>
    <p>Generiert am: ${new Date().toLocaleString("de-DE")}</p>`}
  </div>
  ${c}
  <div class="pdf-content">${o}</div>
</body>
</html>`}async function Yt(r,t={},a="report.pdf"){const n=await fetch(`${Bt}/generate-pdf`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({html:r,options:{...Gt,...t}})});if(!n.ok){const e=await n.text();throw new Error(`PDF generation failed: ${n.statusText} - ${e}`)}const l=await n.blob();if(!l.size)throw new Error("PDF returned empty file");return l}function Kt(r,t){const a=URL.createObjectURL(r),n=document.createElement("a");n.href=a,n.download=t,document.body.appendChild(n),n.click(),URL.revokeObjectURL(a),n.remove()}function Qt(r,t,a="Brückenlager-Eingabeparameter",n="Berechnete Elastomer-Parameter"){const l=[];return r.forEach((e,o)=>{var v,m;const c=t[o],i=o+2;l.push({id:`page-${o+1}`,text:e.title||`Component ${o+1}`,level:1,originalTag:"h1",pageNumber:i}),(e.component.name==="PDFElastoParams"||(v=e.title)!=null&&v.includes("Elastomer-Parameter")||(m=e.title)!=null&&m.includes("Elastomer Parameters"))&&(l.push({id:"input-params",text:a,level:2,originalTag:"h3",pageNumber:i}),l.push({id:"calculated-params",text:n,level:2,originalTag:"h3",pageNumber:i})),pt(c.html).forEach(u=>{u.level>1&&u.id!=="input-params"&&u.id!=="calculated-params"&&l.push({id:`page-${o+1}-${u.id}`,text:u.text,level:Math.min(u.level+1,6),originalTag:u.originalTag,pageNumber:i})})}),l}async function ce(r,t="multi-report",a={},n="statiqs Multi-Component Report",l,e=!0){const{html:o,styles:c,pageInfo:i}=await jt(r);let f;a.includeTableOfContents&&(f=Qt(r,i,a.inputParamsSectionTitle,a.calculatedParamsSectionTitle));const v=Vt(o,c,n,{includeTableOfContents:a.includeTableOfContents,tocTitle:a.tocTitle||"Inhaltsverzeichnis",customTocEntries:f,headerHTML:l,calculationReportSubtitle:a.calculationReportSubtitle}),m=await Yt(v,a,`${t}.pdf`),u=URL.createObjectURL(m);return e&&Kt(m,`${t}.pdf`),{pdfBlob:m,pdfUrl:u}}var Wt=C("<!> ",1),Xt=C("<div><!></div>"),Zt=C("<!> <!> <!> <!>",1);function ue(r,t){bt(t,!1);const a=N(),n=N(),l=N();let e=w(t,"formula",8),o=w(t,"isFulfilled",8,null),c=w(t,"tagTextGood",8,null),i=w(t,"tagTextBad",8,null),f=w(t,"additionalSign1",8,""),v=N(),m=N(T(a)),u=N(!1);O(()=>F(e()),()=>{M(a,e().Result||"")}),O(()=>(F(c()),F(i())),()=>{M(n,c()!=null&&i()!=null)}),O(()=>F(o()),()=>{M(v,o()?"green":"red")}),O(()=>(F(o()),F(c()),F(i())),()=>{M(l,o()?c()||"":i()||"")}),O(()=>(T(a),T(m)),()=>{T(a)!==T(m)&&T(m)!==""&&(M(u,!0),setTimeout(()=>{M(u,!1)},500)),M(m,T(a))}),yt(),ht(),kt(r,{fullWidth:!0,style:"padding: var(--cds-spacing-03);",children:(y,D)=>{Lt(y,{noGutterRight:!0,padding:!1,children:(Y,dt)=>{var K=Zt(),Q=J(K);W(Q,{noGutterRight:!0,sm:2,md:2,lg:2,children:(p,R)=>{ct(p,{padding:0,get formula(){return e().Name}})},$$slots:{default:!0}});var S=A(Q,2);W(S,{noGutterRight:!0,sm:2,md:2,lg:7,children:(p,R)=>{var g=Wt(),x=J(g);ct(x,{get formula(){return e().Abstract}});var s=A(x);V(()=>ut(s,` ${f()??""}`)),E(p,g)},$$slots:{default:!0}});var P=A(S,2);const tt=ft(()=>T(n)?3:7);W(P,{noGutterRight:!0,sm:2,md:2,get lg(){return T(tt)},children:(p,R)=>{var g=Xt();let x;var s=k(g);ct(s,{get formula(){return T(a)}}),L(g),V(_=>x=j(g,1,"svelte-u1m8dl",null,x,_),[()=>({highlighted:T(u)})],ft),E(p,g)},$$slots:{default:!0}});var et=A(P,2);{var z=p=>{W(p,{sm:2,md:2,lg:4,children:(R,g)=>{Ut(R,{get type(){return T(v)},get title(){return T(l)},style:"margin-top: -3px;",children:(x,s)=>{_t();var _=Tt();V(()=>ut(_,T(l))),E(x,_)},$$slots:{default:!0}})},$$slots:{default:!0}})};U(et,p=>{T(n)&&p(z)})}E(Y,K)},$$slots:{default:!0}})},$$slots:{default:!0}}),vt()}export{ue as F,Bt as P,Ut as T,ce as c};
